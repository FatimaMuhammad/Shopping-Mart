package Shoppingmart;

public class buy<E>{

	public E data;
     public buy next;
		
}
